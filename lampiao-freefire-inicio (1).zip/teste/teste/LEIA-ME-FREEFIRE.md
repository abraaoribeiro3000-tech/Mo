<!-- coderabbit-ai-generated:v1 -->

# Free Fire no Lampião — início da integração

Selecione **Free Fire** no seletor de jogo. O painel procura um processo chamado `HD-Player.exe`, usado por emuladores da família BlueStacks. Sua presença não confirma que o Free Fire esteja aberto, o nome comercial ou a versão do emulador.

O objetivo informado é MSI App Player 5.9.300.6315 e BlueStacks 5.13.200.1029 com Free Fire V7A. Essas versões ainda não foram verificadas. ESP de jogadores, ESP de itens e aimbot **não foram implementados**: dependem de uma fonte de dados compatível com a versão instalada do jogo.

A compilação e os testes foram executados no Linux com MinGW/Wine e um processo simulado. Os emuladores reais e o Free Fire não foram executados neste ambiente.

O pacote mantém as versões anteriores dos outros painéis, incluindo a integração experimental do DayZ, cuja compatibilidade com a versão 1.30 permanece não confirmada.
