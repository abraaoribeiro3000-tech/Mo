<!-- coderabbit-ai-generated:v1 -->

# Gerar dados do ARK para o painel

Gerado por CodeRabbit. O painel do ARK incluído no pacote é uma prévia: o ESP e o radar no jogo ainda aguardam a integração dos dados reais.

## Preparar a ferramenta

1. Abra a [versão 1.0.1 do Dumper-7 UE5.8](https://github.com/unchaineddevs-spec/Dumper-7-UE5.8/releases/tag/v1.0.1).
2. Em **Assets**, baixe **Dumper-7.dll** e **Loader.exe** para a mesma pasta.
3. Abra o ARK: Survival Ascended e feche o painel Lampião enquanto gerar os dados.
4. Execute **Loader.exe**. Se o Windows negar o acesso, tente executá-lo como administrador.
5. Aguarde a conclusão indicada na janela do Dumper. O SDK é gravado por padrão em `C:\Dumper-7`. Pressione **F6** para descarregar a ferramenta depois que a geração terminar.
6. Compacte a pasta gerada em `C:\Dumper-7` e envie o ZIP nesta conversa. Se falhar, envie o texto do erro exibido.

O Loader carrega a DLL no processo do jogo; o Dumper também grava `Dumper7_debug.log` ao lado do executável do jogo. O diagnóstico anterior retornou erro de acesso, então a execução pode continuar bloqueada.

A ferramenta é de terceiros. Seu autor relata teste com ARK v97 / UE 5.8.3-838720; a compatibilidade com a sua instalação ainda precisa ser confirmada. Não foi executada no seu jogo durante este trabalho.

Para conferir os arquivos baixados, os SHA-256 informados na release e conferidos aqui são:

- Dumper-7.dll: `d4900e4958bf331cb4ffe0fe742991ac148888773e993b83bbb64da1a5a1d944`
- Loader.exe: `71f1664ec2df7e4c28d2be6c7017f647cdf09849014fa0d1cc6807443c67567b`
