#include "../src/ark_visual.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <cmath>
#include <limits>
using namespace ark_visual;
int main() {
    const std::vector<Entity> values = {
        {Kind::Player, "Ana", {}, {1000,0}},
        {Kind::Animal, "Rex", 150, {0,2000}},
        {Kind::Animal, "Longe", 2, {10001,0}},
        {Kind::Animal, "Inválido", 2, {std::numeric_limits<float>::quiet_NaN(),0}}
    };
    assert(label(values[0]) == "Ana");
    assert(label(values[1]) == "Rex  Nv. 150");
    assert(label({Kind::Animal,"",{}, {}}) == "Animal");
    auto all=radar({0,0},values,{true,true},100,100);
    assert(all.size()==2 && all[0].kind==Kind::Player && all[1].kind==Kind::Animal);
    assert(std::abs(all[0].position.x-10.f)<.001f && std::abs(all[1].position.y+20.f)<.001f);
    assert(radar({0,0},values,{true,false},100,100).size()==1);
    assert(radar({0,0},values,{false,true},100,100).size()==1);
    assert(radar({0,0},values,{false,false},100,100).empty());
    assert(radar({0,0},values,{true,true},0,100).empty());
    assert(radar({NAN,0},values,{true,true},100,100).empty());
}
