#include "../src/dayz.hpp"
#include <map>
#include <cstring>
#include <cstdio>
using namespace crimson;
struct Fake {
    std::map<uint64_t,unsigned char> memory;
    template<class T> void put(uint64_t p,const T& v){putBytes(p,&v,sizeof v);}
    void putBytes(uint64_t p,const void* v,size_t n){auto b=static_cast<const unsigned char*>(v);for(size_t i=0;i<n;++i)memory[p+i]=b[i];}
    bool read(uint64_t p,void* v,size_t n)const{auto out=static_cast<unsigned char*>(v);for(size_t i=0;i<n;++i){auto it=memory.find(p+i);if(it==memory.end())return false;out[i]=it->second;}return true;}
    template<class T> bool read(uint64_t p,T& out)const{return read(p,&out,sizeof out);}
};
static void entity(Fake& m,uint64_t entity,uint64_t type,uint64_t str,uint64_t visual,const char* name,Vec3 pos,uint8_t dead=0){
    m.put(entity+0x180,type);m.put(type+0x4F0,str);uint32_t n=static_cast<uint32_t>(std::strlen(name));m.put(str+8,n);m.putBytes(str+16,name,n);m.put(entity+0x1C8,visual);m.put(visual+0x2C,pos);m.put(entity+0xE2,dead);
}
int main(){
    int fails=0;auto check=[&](bool v,const char* msg){if(!v){std::printf("FAIL: %s\n",msg);++fails;}};
    Fake m;uint64_t base=0x1000000,world=0x2000000,cam=0x2100000,actors=0x2200000,table=0x2300000;
    m.put(base+dayz::worldOffset,world);m.put(world+dayz::cameraOffset,cam);
    m.put(cam+0x8,Vec3{1,0,0});m.put(cam+0x14,Vec3{0,1,0});m.put(cam+0x20,Vec3{0,0,1});m.put(cam+0x2C,Vec3{0,0,0});
    m.put(cam+0xD0,Vec3{1,0,0});m.put(cam+0xDC,Vec3{0,1,0});
    m.put(world+dayz::nearOffset,actors);m.put(world+dayz::nearOffset+8,uint32_t{4});
    m.put(world+dayz::farOffset,uint64_t{0});m.put(world+dayz::farOffset+8,uint32_t{0});
    uint64_t list[]={0x3000000,0x3100000,0x3200000,0x3300000};m.putBytes(actors,list,sizeof list);
    entity(m,list[0],0x4000000,0x4100000,0x4200000,"SurvivorM_Test",{1,0,20});
    entity(m,list[1],0x4300000,0x4400000,0x4500000,"ZmbM_Test",{0,0,10});
    entity(m,list[2],0x4600000,0x4700000,0x4800000,"SurvivorF_Local",{0,0,1});
    entity(m,list[3],0x4900000,0x4A00000,0x4B00000,"SurvivorM_Dead",{0,0,30},1);
    m.put(world+dayz::itemOffset,table);m.put(world+dayz::itemOffset+8,uint32_t{1});
    struct Entry{uint32_t present,pad;uint64_t entity,other;};m.put(table,Entry{1,0,0x5000000,0});
    entity(m,0x5000000,0x5100000,0x5200000,0x5300000,"Bandage",{0,0,15});
    auto f=dayz::sample(m,base,42);check(f.ready&&f.pid==42,"synthetic snapshot ready");
    check(f.players.size()==1&&f.players[0].name=="SurvivorM_Test","only living nonlocal players selected");
    check(f.items.size()==1&&f.items[0].name=="Bandage","item table and name read");
    Vec2 screen{};check(dayz::projectPoint(f.camera,Vec3{0,0,20},1920,1080,screen)&&screen.x==960&&screen.y==540,"camera projects center");
    check(!dayz::projectPoint(f.camera,Vec3{0,0,-20},1920,1080,screen),"reject behind camera");
    auto aim=dayz::aimDelta(f,1920,1080,120,12);check(aim.target&&aim.dx>0&&aim.dy<0,"aim selects visible head");
    check(!dayz::aimDelta(f,1920,1080,10,12).target,"aim respects FOV");
    f.ready=false;check(!dayz::aimDelta(f,1920,1080,120,12).target,"aim stops when frame unavailable");
    m.put(cam+0xD0,Vec3{0,0,0});check(!dayz::sample(m,base,42).ready,"reject invalid camera");
    if(!fails)std::puts("DayZ synthetic tests passed");return fails?1:0;
}
