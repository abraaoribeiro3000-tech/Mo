#include "../src/game_selection.hpp"
#include <cstdio>

using namespace games;
int main() {
    int failures = 0;
    auto check = [&](bool value, const char* name) { if (!value) { std::printf("FAIL: %s\n", name); ++failures; } };
    Detection none{};
    check(active(Preference::Automatic, none) == Game::CS2, "detection error retains CS2");
    none.available = true;
    check(active(Preference::Automatic, none) == Game::CS2, "no games retains CS2");
    Detection result{}; result.available = true;
    classify(L"ARMAREFORGERSTEAM.EXE", result);
    classify(L"unrelated.exe", result);
    check(result.reforger && !result.cs2, "case insensitive detection");
    check(active(Preference::Automatic, result) == Game::Reforger, "automatic reforger");
    check(active(Preference::CS2, result) == Game::CS2, "manual CS2 overrides");
    classify(L"Cs2.Exe", result);
    check(result.reforger && result.cs2, "both games detected");
    check(active(Preference::Automatic, result) == Game::CS2, "automatic prioritizes CS2");
    check(active(Preference::Reforger, result) == Game::Reforger, "manual reforger overrides");
    result.reforger = false;
    check(active(Preference::Automatic, result) == Game::CS2, "automatic cs2");
    check(active(Preference::Reforger, result) == Game::Reforger, "manual reforger while absent");
    Detection ark{}; ark.available = true;
    classify(L"arkascended.EXE", ark);
    check(ark.ark && !ark.cs2 && !ark.reforger, "case insensitive ARK detection");
    check(active(Preference::Automatic, ark) == Game::Ark, "automatic ARK");
    check(active(Preference::Ark, none) == Game::Ark, "manual ARK while absent");
    ark.reforger = true;
    check(active(Preference::Automatic, ark) == Game::Reforger, "reforger priority over ARK");
    ark.cs2 = true;
    check(active(Preference::Automatic, ark) == Game::CS2, "CS2 priority with all games");
    check(active(Preference::Ark, ark) == Game::Ark, "manual ARK overrides");
    Detection dz{}; dz.available = true; classify(L"DAYZ_X64.EXE", dz);
    check(dz.dayz && active(Preference::Automatic, dz) == Game::DayZ, "automatic DayZ detection");
    check(active(Preference::DayZ, none) == Game::DayZ, "manual DayZ while absent");
    dz.ark = true; check(active(Preference::Automatic, dz) == Game::Ark, "ARK priority over DayZ");
    check(active(Preference::DayZ, dz) == Game::DayZ, "manual DayZ overrides");
    Detection emulator{}; emulator.available = true;
    classify(L"hD-pLaYeR.ExE", emulator);
    check(emulator.hdPlayer, "case insensitive emulator detection");
    check(active(Preference::Automatic, emulator) == Game::CS2, "emulator alone does not imply Free Fire");
    check(active(Preference::FreeFire, none) == Game::FreeFire, "manual Free Fire without emulator");
    check(active(Preference::FreeFire, dz) == Game::FreeFire, "manual Free Fire overrides other games");
    auto real = detect();
    check(real.available || real.error != ERROR_SUCCESS, "detection result reports errors");
    if (!failures) std::puts("game selection tests passed");
    return failures ? 1 : 0;
}
