<!-- coderabbit-ai-generated:v1 -->

# DayZ no Lampião — integração experimental

O painel inclui ESP de jogadores, ESP de itens e aimbot para DayZ. A leitura é externa e usa as estruturas da base pública [Spectre](https://github.com/Cr0mb/Spectre-Fully-Featured-DayZ-Python-Cheat/tree/f085d038b4766a967f6fe68fe60d67aa6d2c7298), identificada pelo autor como 1.29. A compatibilidade com sua instalação não foi confirmada; o autor dessa base informa que ela não funciona com BattlEye.

## Como usar

1. Extraia todo o ZIP para uma pasta e inicie o painel por `teste/teste/Iniciar.bat`.
2. Selecione **DayZ** no painel ou use a seleção automática quando somente o DayZ estiver aberto.
3. Ative ESP de jogadores, ESP de itens e/ou aimbot no painel. As opções começam desligadas e não são salvas.
4. Para a mira, segure o botão direito do mouse com a janela do DayZ em foco. Os controles FOV e suavidade ficam no painel. **Insert** mostra ou oculta o painel; **End** encerra.

A janela **Estado** mostra se a leitura foi disponibilizada. Ela pode falhar se o acesso ao processo for negado ou se o jogo usar outra estrutura. Os nomes de jogadores são exibidos como “Jogador”; os itens usam os nomes que o jogo disponibilizar. O ESP estima a posição da cabeça a partir da posição do personagem. O aimbot usa somente os alvos reconhecidos e ajusta o mouse enquanto o botão estiver pressionado.

## Limitações e verificações

A compilação e os testes foram executados com MinGW/Wine e dados simulados, incluindo um processo e uma janela sintéticos. O DayZ real não foi executado nem foram confirmados acesso, versão, projeção, identificação de entidades ou resposta da mira no jogo. Se a leitura for bloqueada ou incompatível, as funções não operam. Nenhum driver é fornecido ou carregado por esta integração.

O painel do ARK continua sendo uma prévia com dados simulados; a integração do CS2 existente também foi preservada.
