#pragma once
#include <cmath>
#include <optional>
#include <string>
#include <vector>

// ARK world coordinates are expressed in centimetres. The reader must provide
// screen coordinates separately; this module does not guess camera layout.
namespace ark_visual {
enum class Kind { Player, Animal };
struct Point { float x{}, y{}; };
struct Entity {
    Kind kind{};
    std::string name;
    std::optional<int> level;
    Point world{};
};
struct Filters { bool players = true; bool animals = true; };
struct RadarMarker { Point position; Kind kind; };
inline bool visible(Kind kind, const Filters& filters) {
    return kind == Kind::Player ? filters.players : filters.animals;
}
inline std::string label(const Entity& entity) {
    std::string result = entity.name.empty() ? (entity.kind == Kind::Animal ? "Animal" : "Jogador") : entity.name;
    if (entity.kind == Kind::Animal && entity.level && *entity.level > 0)
        result += "  Nv. " + std::to_string(*entity.level);
    return result;
}
inline std::vector<RadarMarker> radar(Point local, const std::vector<Entity>& entities,
                                      Filters filters, float rangeMeters, float radius) {
    std::vector<RadarMarker> result;
    if (!std::isfinite(local.x) || !std::isfinite(local.y) || !std::isfinite(rangeMeters) ||
        !std::isfinite(radius) || rangeMeters <= 0 || radius <= 0) return result;
    for (const auto& entity : entities) {
        if (!visible(entity.kind, filters) || !std::isfinite(entity.world.x) || !std::isfinite(entity.world.y)) continue;
        float dx = (entity.world.x - local.x) * 0.01f;
        float dy = (entity.world.y - local.y) * 0.01f;
        if (!std::isfinite(dx) || !std::isfinite(dy) || std::hypot(dx, dy) > rangeMeters) continue;
        result.push_back({{dx * radius / rangeMeters, -dy * radius / rangeMeters}, entity.kind});
    }
    return result;
}
}
