#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <tlhelp32.h>
#include <cwchar>

namespace games {
enum class Preference { Automatic = 0, CS2 = 1, Reforger = 2, Ark = 3, DayZ = 4, FreeFire = 5 };
enum class Game { CS2, Reforger, Ark, DayZ, FreeFire };
struct Detection {
    bool available = false;
    bool cs2 = false;
    bool reforger = false;
    bool ark = false;
    bool dayz = false;
    bool hdPlayer = false;
    DWORD error = ERROR_SUCCESS;
};
inline void classify(const wchar_t* name, Detection& result) {
    if (!name) return;
    if (_wcsicmp(name, L"cs2.exe") == 0) result.cs2 = true;
    else if (_wcsicmp(name, L"ArmaReforgerSteam.exe") == 0) result.reforger = true;
    else if (_wcsicmp(name, L"ArkAscended.exe") == 0) result.ark = true;
    else if (_wcsicmp(name, L"DayZ_x64.exe") == 0) result.dayz = true;
    else if (_wcsicmp(name, L"HD-Player.exe") == 0) result.hdPlayer = true;
}
inline Detection detect() {
    Detection result;
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) { result.error = GetLastError(); return result; }
    PROCESSENTRY32W entry{};
    entry.dwSize = sizeof(entry);
    if (!Process32FirstW(snapshot, &entry)) {
        result.error = GetLastError();
        CloseHandle(snapshot);
        return result;
    }
    do { classify(entry.szExeFile, result); } while (Process32NextW(snapshot, &entry));
    DWORD error = GetLastError();
    CloseHandle(snapshot);
    if (error != ERROR_NO_MORE_FILES) { result.error = error; return result; }
    result.available = true;
    return result;
}
// Automatic mode prioritizes CS2 when both games are detected and keeps the
// existing CS2 panel when no game is detected or detection is unavailable.
// Reforger retains priority over ARK when both are detected without CS2.
inline Game active(Preference preference, const Detection& detection) {
    if (preference == Preference::CS2) return Game::CS2;
    if (preference == Preference::Reforger) return Game::Reforger;
    if (preference == Preference::Ark) return Game::Ark;
    if (preference == Preference::DayZ) return Game::DayZ;
    if (preference == Preference::FreeFire) return Game::FreeFire;
    if (detection.available && !detection.cs2) {
        if (detection.reforger) return Game::Reforger;
        if (detection.ark) return Game::Ark;
        if (detection.dayz) return Game::DayZ;
    }
    return Game::CS2;
}
}
