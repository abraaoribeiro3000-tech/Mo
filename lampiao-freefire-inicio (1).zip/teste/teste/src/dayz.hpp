#pragma once
#include "core.hpp"
#include <cctype>
#include <unordered_set>

// Compatibility reference: public Spectre DayZ 1.29 layout, commit f085d038.
// The build identifier is not verified; values must be validated on the target game.
namespace crimson::dayz {
constexpr uint64_t worldOffset=0x4263FE8, cameraOffset=0x1B8, nearOffset=0xF48, farOffset=0x1090, itemOffset=0x2060;
struct Camera { Vec3 position{},right{},up{},forward{}; float projectionX{},projectionY{}; };
struct Entity { Vec3 position{}; std::string name; float meters{}; };
struct Frame { DWORD pid{}; bool ready{}; std::string status="Aguardando DayZ_x64.exe"; Camera camera{}; std::vector<Entity> players,items; std::chrono::steady_clock::time_point sampled{}; };
inline bool finite(Vec3 v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z)&&std::abs(v.x)<1000000&&std::abs(v.y)<1000000&&std::abs(v.z)<1000000;}
inline float dot(Vec3 a,Vec3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
inline float length(Vec3 a){return std::sqrt(dot(a,a));}
inline bool vectorOK(Vec3 a){float l=length(a);return finite(a)&&l>.1f&&l<3.f;}
inline bool projectPoint(const Camera& c,Vec3 p,float width,float height,Vec2& out){
    if(!finite(p)||width<=0||height<=0||!std::isfinite(c.projectionX)||!std::isfinite(c.projectionY)||std::abs(c.projectionX)<.001f||std::abs(c.projectionY)<.001f)return false;
    Vec3 d{p.x-c.position.x,p.y-c.position.y,p.z-c.position.z};float z=dot(d,c.forward);
    if(!std::isfinite(z)||z<.1f)return false;
    out={width*.5f*(1+dot(d,c.right)/(c.projectionX*z)),height*.5f*(1-dot(d,c.up)/(c.projectionY*z))};
    return std::isfinite(out.x)&&std::isfinite(out.y)&&out.x>=0&&out.y>=0&&out.x<=width&&out.y<=height;
}
inline bool headProjection(const Camera& c,const Entity& e,float width,float height,Vec2& p){auto head=e.position;head.y+=1.6f;return projectPoint(c,head,width,height,p);}
struct AimDelta { LONG dx{},dy{}; bool target{}; };
inline AimDelta aimDelta(const Frame& f,float width,float height,float radius,float smooth){
    if(!f.ready||radius<=0||smooth<1)return {};
    float best=radius*radius;Vec2 found{};bool hit=false;
    for(const auto& e:f.players){Vec2 p{};if(!headProjection(f.camera,e,width,height,p))continue;float dx=p.x-width*.5f,dy=p.y-height*.5f;float d=dx*dx+dy*dy;if(d<best){best=d;found=p;hit=true;}}
    if(!hit)return {};
    float dx=std::clamp((found.x-width*.5f)/smooth,-80.f,80.f),dy=std::clamp((found.y-height*.5f)/smooth,-80.f,80.f);
    return {static_cast<LONG>(std::lround(dx)),static_cast<LONG>(std::lround(dy)),true};
}
template<class M,class T> inline bool readAt(const M& mem,uint64_t ptr,T& value){return ptr>=0x10000 && ptr<0x7FFFFFFF0000ULL && mem.read(ptr,value);}
template<class M> inline bool pointer(const M& mem,uint64_t p,uint64_t& out){return readAt(mem,p,out)&&out>=0x10000&&out<0x7FFFFFFF0000ULL;}
template<class M> inline bool camera(const M& m,uint64_t p,Camera& c){
    Vec3 projectionX{},projectionY{};
    if(!readAt(m,p+0x2C,c.position)||!readAt(m,p+0x8,c.right)||!readAt(m,p+0x14,c.up)||!readAt(m,p+0x20,c.forward)||!readAt(m,p+0xD0,projectionX)||!readAt(m,p+0xDC,projectionY))return false;
    c.projectionX=projectionX.x;c.projectionY=projectionY.y;
    return finite(c.position)&&vectorOK(c.right)&&vectorOK(c.up)&&vectorOK(c.forward)&&std::isfinite(c.projectionX)&&std::isfinite(c.projectionY)&&std::abs(c.projectionX)>.01f&&std::abs(c.projectionY)>.01f;
}
template<class M> inline bool objectName(const M& m,uint64_t ent,std::string& name){
    uint64_t type{},str{};uint32_t count{};
    if(!pointer(m,ent+0x180,type)||!pointer(m,type+0x4F0,str)||!readAt(m,str+8,count)||count==0||count>128)return false;
    std::array<char,129> text{};if(!m.read(str+16,text.data(),count))return false;
    for(uint32_t i=0;i<count;++i)if(static_cast<unsigned char>(text[i])<32 && text[i]!=0)return false;
    name.assign(text.data(),std::find(text.data(),text.data()+count,'\0'));return !name.empty();
}
template<class M> inline bool entity(const M& m,uint64_t p,const Camera& c,Entity& e){
    uint64_t visual{};if(!pointer(m,p+0x1C8,visual)||!readAt(m,visual+0x2C,e.position)||!finite(e.position)||!objectName(m,p,e.name))return false;
    Vec3 d{e.position.x-c.position.x,e.position.y-c.position.y,e.position.z-c.position.z};e.meters=length(d);
    return std::isfinite(e.meters)&&e.meters<1500.f;
}
inline bool playerName(std::string name){for(auto& c:name)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));return name.find("survivor")!=std::string::npos;}
template<class M> inline bool array(const M& m,uint64_t at,std::vector<uint64_t>& out){
    uint64_t data{};uint32_t count{};if(!readAt(m,at,data)||!readAt(m,at+8,count)||count>4096)return false;
    if(!count)return true;if(data<0x10000||data>=0x7FFFFFFF0000ULL)return false;
    std::vector<uint64_t> buf(count);if(!m.read(data,buf.data(),buf.size()*sizeof(uint64_t)))return false;
    out.insert(out.end(),buf.begin(),buf.end());return true;
}
template<class M> inline bool actorsAt(const M& m,uint64_t field,std::vector<uint64_t>& out){
    std::vector<uint64_t> temp;if(array(m,field,temp)){out.insert(out.end(),temp.begin(),temp.end());return true;}
    uint64_t indirect{};return pointer(m,field,indirect)&&array(m,indirect,out);
}
template<class M> inline bool itemTable(const M& m,uint64_t world,std::vector<uint64_t>& out){
    uint64_t data{};uint32_t capacity{};if(!readAt(m,world+itemOffset,data)||!readAt(m,world+itemOffset+8,capacity)||capacity>4096)return false;
    if(!capacity)return true;if(data<0x10000||data>=0x7FFFFFFF0000ULL)return false;
    struct Entry{uint32_t present,pad;uint64_t entity,other;};static_assert(sizeof(Entry)==24);
    std::vector<Entry> entries(capacity);if(!m.read(data,entries.data(),entries.size()*sizeof(Entry)))return false;
    for(const auto& e:entries)if(e.present==1&&e.entity)out.push_back(e.entity);return true;
}
template<class M> inline Frame sample(const M& m,uint64_t base,DWORD pid){
    Frame f;f.pid=pid;f.status="Dados DayZ indisponiveis ou versao incompativel";
    uint64_t world{},cam{};if(!pointer(m,base+worldOffset,world)||!pointer(m,world+cameraOffset,cam)||!camera(m,cam,f.camera))return f;
    std::vector<uint64_t> actors,items;bool nearOk=actorsAt(m,world+nearOffset,actors),farOk=actorsAt(m,world+farOffset,actors),loot=itemTable(m,world,items);
    if(!nearOk&&!farOk&&!loot)return f;
    std::unordered_set<uint64_t> seen;
    for(auto p:actors){if(!seen.insert(p).second)continue;Entity e;uint8_t dead{};
        if(!entity(m,p,f.camera,e)||!playerName(e.name)||e.meters<5.f||!readAt(m,p+0xE2,dead)||dead)continue;
        f.players.push_back(std::move(e));}
    seen.clear();for(auto p:items){if(!seen.insert(p).second)continue;Entity e;if(entity(m,p,f.camera,e)&&e.meters<=300.f)f.items.push_back(std::move(e));}
    f.sampled=std::chrono::steady_clock::now();f.ready=true;f.status="Leitura experimental ativa";return f;
}
class Reader {
    std::atomic<bool> quit{false},enabled{false};std::mutex mutex;Frame current;std::thread worker;
    void publish(Frame f){std::lock_guard lock(mutex);current=std::move(f);}
    static DWORD find(){Handle list(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0));if(!list)return 0;PROCESSENTRY32W e{sizeof e};if(Process32FirstW(list.value,&e))do{if(_wcsicmp(e.szExeFile,L"DayZ_x64.exe")==0)return e.th32ProcessID;}while(Process32NextW(list.value,&e));return 0;}
    void run(){Process p;auto next=std::chrono::steady_clock::time_point{};
        while(!quit){if(!enabled){if(p.alive())p.close();std::this_thread::sleep_for(std::chrono::milliseconds(100));continue;}
            auto now=std::chrono::steady_clock::now();
            if(!p.alive()) {p.close();if(now<next){std::this_thread::sleep_for(std::chrono::milliseconds(100));continue;}next=now+std::chrono::seconds(2);Frame f;DWORD id=find();
                if(!id){publish(f);continue;}f.pid=id;
                p.handle.reset(OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_INFORMATION,FALSE,id));if(!p.handle){f.status="Acesso ao DayZ indisponivel";publish(f);continue;}p.pid=id;
                Handle mods(CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,id));MODULEENTRY32W entry{sizeof entry};
                if(mods&&Module32FirstW(mods.value,&entry))do{if(_wcsicmp(entry.szModule,L"DayZ_x64.exe")==0 && entry.modBaseSize>worldOffset+8){p.base=reinterpret_cast<uint64_t>(entry.modBaseAddr);break;}}while(Module32NextW(mods.value,&entry));
                if(!p.base){f.status="Modulo indisponivel ou versao incompativel";publish(f);p.close();continue;}
            }
            publish(sample(p,p.base,p.pid));std::this_thread::sleep_for(std::chrono::milliseconds(80));
        }
    }
public:
    Reader():worker([this]{run();}){} ~Reader(){quit=true;worker.join();}
    void setEnabled(bool value){enabled=value;}
    Frame snapshot(){std::lock_guard lock(mutex);return current;}
};
}
